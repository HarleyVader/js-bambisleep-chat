"""
Prompt builder utilities for MCP.
Provides:
- assemble_prompt(query, items, template, max_tokens, policy)
  returns: { prompt, provenance, safeguards }
Safeguards include: removed_items, redactions, policy_violations
"""
from typing import List, Dict, Any, Tuple
import datetime
import math
import html
import re

# Simple token estimate (approx): tokens ≈ words * 0.75
def estimate_tokens(text: str) -> int:
    words = len(text.split())
    return max(1, math.ceil(words * 0.75))

def redact_pii(text: str) -> Tuple[str, List[str]]:
    # Very simple PII regexes for demo. Replace with production PII detectors.
    patterns = {
        "email": r"[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+",
        "ssn": r"\b\d{3}-\d{2}-\d{4}\b",
        "credit_card": r"\b(?:\d[ -]*?){13,16}\b"
    }
    redactions = []
    redacted = text
    for name, pat in patterns.items():
        matches = re.findall(pat, redacted)
        for m in matches:
            redactions.append(f"{name}:{m}")
            redacted = redacted.replace(m, f"[REDACTED:{name}]")
    return redacted, redactions

def format_provenance(items: List[Dict[str, Any]]) -> str:
    lines = []
    for it in items:
        src = it.get("source", {}) or {}
        uri = src.get("uri") or src.get("path") or ""
        lines.append(f"- id={it.get('id')} source={uri} chunk={it.get('chunk_index')} score={it.get('retrieval',{}).get('relevance_score')}")
    return "\n".join(lines)

def safe_filter_items(items: List[Dict[str, Any]], requester: Dict[str,Any], policy: Dict[str,Any]=None) -> Tuple[List[Dict[str,Any]], List[Dict[str,Any]]]:
    kept = []
    removed = []
    for it in items:
        sensitivity = it.get("sensitivity","internal")
        # Basic policy: requester must have allowed_sensitivity list
        allowed = requester.get("allowed_sensitivity", ["public","internal"])
        if sensitivity not in allowed:
            removed.append({"id": it.get("id"), "reason": f"sensitivity={sensitivity}"})
            continue
        # additional checks could be inserted here (roles, tags, date)
        kept.append(it)
    return kept, removed

def assemble_prompt(query: str,
                    items: List[Dict[str, Any]],
                    template: str = None,
                    max_tokens: int = 2048,
                    requester: Dict[str,Any] = None,
                    policy: Dict[str,Any] = None) -> Dict[str,Any]:
    requester = requester or {}
    policy = policy or {}

    # 1) Apply sensitivity filter
    filtered_items, removed_by_policy = safe_filter_items(items, requester, policy)

    # 2) Run lightweight PII redaction per item
    provenance_list = []
    safeguards = {
        "removed_items": removed_by_policy,
        "redactions": [],
        "policy_violations": []
    }

    # Sort by relevance score descending
    sorted_items = sorted(filtered_items, key=lambda x: x.get("retrieval",{}).get("relevance_score", 0), reverse=True)

    # Build candidate body and measure tokens
    chunks = []
    total_tokens = estimate_tokens(template or "") + estimate_tokens(query)
    for it in sorted_items:
        content = it.get("content") or ""
        # redact PII
        redacted_content, redactions = redact_pii(content)
        if redactions:
            safeguards["redactions"].append({"id": it.get("id"), "redactions": redactions})
        item_tokens = estimate_tokens(redacted_content)
        # If item itself exceeds whole budget, trim conservatively (keep first N chars)
        if item_tokens + total_tokens > max_tokens:
            # try to append only if small portion fits
            allowed = max_tokens - total_tokens
            if allowed <= 0:
                break
            # approximate allowed chars: choose words ~ tokens/0.75
            approx_words_allowed = max(5, int(allowed / 0.75))
            truncated = " ".join(redacted_content.split()[:approx_words_allowed])
            chunks.append({"id": it.get("id"), "content": truncated, "truncated": True, "source": it.get("source")})
            total_tokens += estimate_tokens(truncated)
        else:
            chunks.append({"id": it.get("id"), "content": redacted_content, "truncated": False, "source": it.get("source")})
            total_tokens += item_tokens

        provenance_list.append({
            "id": it.get("id"),
            "source": it.get("source", {}),
            "chunk_index": it.get("chunk_index"),
            "relevance_score": it.get("retrieval",{}).get("relevance_score")
        })

    # Build prompt
    if template:
        # Replace placeholders {{context}} and {{query}} and {{provenance}}
        context_block = "\n\n".join([f"---\nSource: {c.get('source',{}).get('uri','')}\nContent:\n{c.get('content')}" for c in chunks])
        provenance_block = format_provenance(provenance_list)
        prompt = template.replace("{{context}}", context_block).replace("{{query}}", query).replace("{{provenance}}", provenance_block)
    else:
        # default template
        context_block = "\n\n".join([f"Source: {c.get('source',{}).get('uri','')}\n{c.get('content')}" for c in chunks])
        provenance_block = format_provenance(provenance_list)
        prompt = f"Use the following context to answer the question. Include provenance. \n\nContext:\n{context_block}\n\nQuestion: {query}\n\nProvenance:\n{provenance_block}"

    return {
        "prompt": prompt,
        "provenance": provenance_list,
        "safeguards": safeguards,
        "token_estimate": total_tokens,
        "assembled_at": datetime.datetime.utcnow().isoformat() + "Z"
    }