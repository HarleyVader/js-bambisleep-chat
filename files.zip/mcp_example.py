"""
MCP example pipeline (simple, self-contained).

Flow:
- ingest_document(text_or_path) -> produces context_items
- embed_items(items) -> attaches embedding vectors or ids
- store_items(items) -> saves to local index (pickle or in-memory)
- retrieve(query, top_k) -> similarity search + metadata filter
- assemble_prompt(query, items) -> uses prompt_builder.assemble_prompt

This example uses OpenAI embeddings if OPENAI_API_KEY is set; otherwise uses deterministic pseudo-embeddings.
"""
import os
import sys
import json
import math
import pickle
import hashlib
import numpy as np
from typing import List, Dict, Any
from prompt_builder import assemble_prompt
from datetime import datetime

STORE_PATH = "mcp_store.pkl"
EMBED_DIM = 1536  # default OpenAI embedding dim for text-embedding-ada-002; adapt as needed

def sha256_text(t: str) -> str:
    return "sha256:" + hashlib.sha256(t.encode("utf-8")).hexdigest()

def chunk_text(text: str, max_tokens=400) -> List[str]:
    # Simple paragraph-based chunking with fallback to sliding window by sentences.
    paras = [p.strip() for p in text.split("\n\n") if p.strip()]
    chunks = []
    for p in paras:
        if len(p.split()) <= max_tokens:
            chunks.append(p)
        else:
            # split roughly by sentences
            sentences = p.split(". ")
            cur = []
            cur_len = 0
            for s in sentences:
                s_len = len(s.split())
                if cur_len + s_len > max_tokens:
                    chunks.append(". ".join(cur).strip())
                    cur = [s]
                    cur_len = s_len
                else:
                    cur.append(s)
                    cur_len += s_len
            if cur:
                chunks.append(". ".join(cur).strip())
    return chunks

# Embedding provider: uses OpenAI if key present; otherwise uses deterministic hash->vector
def get_embedding(text: str, model: str = "openai-embedding-1") -> List[float]:
    try:
        import openai
        api_key = os.environ.get("OPENAI_API_KEY")
        if api_key:
            openai.api_key = api_key
            resp = openai.Embedding.create(input=text, model=model)
            vec = resp["data"][0]["embedding"]
            return vec
    except Exception:
        pass
    # deterministic pseudo-embedding fallback: use sha256 as bytes to seed RNG
    h = hashlib.sha256(text.encode("utf-8")).digest()
    seed = int.from_bytes(h[:8], "big")
    rng = np.random.RandomState(seed)
    vec = rng.normal(size=(EMBED_DIM,)).astype(float)
    # normalize
    vec = vec / np.linalg.norm(vec)
    return vec.tolist()

# store schema: dict with 'items': list[context_item], 'vectors': np.ndarray (N, D), 'ids': list[str]
def load_store(path=STORE_PATH) -> Dict[str,Any]:
    if os.path.exists(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    return {"items": [], "vectors": None, "ids": []}

def save_store(store: Dict[str,Any], path=STORE_PATH):
    with open(path, "wb") as f:
        pickle.dump(store, f)

def ingest_document_text(text: str, source_uri: str = None, language: str="en") -> List[Dict[str,Any]]:
    chunks = chunk_text(text)
    items = []
    now = datetime.utcnow().isoformat() + "Z"
    for i, c in enumerate(chunks):
        cid = f"doc-{sha256_text(c)}-{i}"
        item = {
            "id": cid,
            "type": "document_chunk",
            "title": None,
            "source": {"uri": source_uri} if source_uri else {},
            "content_type": "text/plain",
            "content": c,
            "content_hash": sha256_text(c),
            "chunk_index": i,
            "chunk_size": len(c.split()),
            "language": language,
            "tags": [],
            "sensitivity": "public",
            "provenance": {"ingest_pipeline":"example-pipeline", "processing_steps":[{"step":"chunked","timestamp":now}]},
            "metadata": {}
        }
        items.append(item)
    return items

def embed_items(items: List[Dict[str,Any]], model:str="openai-embedding-1") -> List[Dict[str,Any]]:
    for it in items:
        v = get_embedding(it.get("content",""), model=model)
        it.setdefault("embedding", {})
        it["embedding"]["model"] = model
        it["embedding"]["vector"] = v
    return items

def store_items(items: List[Dict[str,Any]], path=STORE_PATH):
    store = load_store(path)
    ids = store["ids"]
    vectors = store["vectors"]
    for it in items:
        vec = np.array(it["embedding"]["vector"], dtype=np.float32)
        if vectors is None:
            vectors = vec.reshape(1, -1)
        else:
            vectors = np.vstack([vectors, vec.reshape(1, -1)])
        store.setdefault("items", []).append(it)
        ids.append(it["id"])
    store["vectors"] = vectors
    store["ids"] = ids
    save_store(store, path)
    return store

def cosine_similarity_matrix(query_vec: np.ndarray, vectors: np.ndarray) -> np.ndarray:
    # vectors: (N, D), query_vec: (D,)
    if vectors is None or vectors.shape[0]==0:
        return np.array([])
    # normalize
    q = query_vec / np.linalg.norm(query_vec)
    vs = vectors / np.linalg.norm(vectors, axis=1, keepdims=True)
    sims = vs.dot(q)
    return sims

def retrieve(query: str, top_k: int = 5, filter_fn=None, path=STORE_PATH) -> List[Dict[str,Any]]:
    store = load_store(path)
    vectors = store["vectors"]
    items = store.get("items", [])
    if vectors is None or len(items)==0:
        return []
    qv = np.array(get_embedding(query), dtype=np.float32)
    sims = cosine_similarity_matrix(qv, vectors)
    # sort
    idxs = np.argsort(-sims)[:top_k]
    results = []
    for idx in idxs:
        item = items[int(idx)].copy()
        item.setdefault("retrieval", {})
        item["retrieval"]["relevance_score"] = float(sims[int(idx)])
        item["retrieval"]["retrieved_at"] = datetime.utcnow().isoformat() + "Z"
        if filter_fn and not filter_fn(item):
            continue
        results.append(item)
    return results

def demo_flow():
    # 1) ingest
    sample_text = """MCP (Model Context Protocol) is a schema for packaging context for LLMs.
It allows chunking, provenance, sensitivity, and embeddings.\n\nThis is the second paragraph with more details.
It includes examples and best practices."""
    items = ingest_document_text(sample_text, source_uri="demo:sample_doc")
    print(f"Ingested {len(items)} items.")

    # 2) embed
    items = embed_items(items)
    print("Embeddings attached.")

    # 3) store
    store = store_items(items)
    print(f"Stored items. Total stored ids: {len(store['ids'])}")

    # 4) retrieve
    q = "What is MCP and what does it include?"
    results = retrieve(q, top_k=3)
    print(f"Retrieved {len(results)} items (top_k=3).")
    for r in results:
        print(f" - {r['id']} score={r['retrieval']['relevance_score']:.4f}")

    # 5) assemble prompt
    template = "System: You are an assistant.\n\nContext:\n{{context}}\n\nQuestion:\n{{query}}\n\nProvenance:\n{{provenance}}"
    requester = {"user_id":"demo-user", "allowed_sensitivity": ["public", "internal"]}
    assembled = assemble_prompt(q, results, template=template, max_tokens=1024, requester=requester)
    print("\nAssembled prompt preview (truncated):\n")
    print(assembled["prompt"][:1000])
    print("\nProvenance:", assembled["provenance"])
    print("\nSafeguards:", assembled["safeguards"])

if __name__ == "__main__":
    demo_flow()