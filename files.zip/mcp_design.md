```markdown
# Model Context Protocol (MCP) — Design & Use Case Review

This document explains the MCP design choices and maps them to three concrete use cases: Knowledge Base, Code Assistant, and Helpdesk.

## Goals recap
- Provide predictable, auditable context packages to LLMs.
- Track provenance and integrity (hashes/signatures).
- Enable filtering (privacy/sensitivity/policies).
- Make prompt assembly deterministic, cost-aware, and safe.

## Core schema highlights
- context_item.id: stable per-chunk identifier.
- content vs content_ref: support inline content or external references.
- embedding: optionally include vector or just an embedding_id pointing into a vector index.
- provenance.processing_steps: exact timestamps and steps for reproducibility.
- sensitivity + tags: primary controls for policy enforcement.

## Pipeline components
1. Ingest: parsing, language detection, metadata extraction.
2. Chunking: semantic boundaries, keep chunk_size and chunk_index.
3. Embedding & indexing: attach embedding.model and vector or embedding_id.
4. Retrieval: similarity + metadata filter.
5. Prompt assembly: ordering by relevance, token budget, redaction.
6. Audit & logging: record package_id, selected item ids, scores, and model response.

## Token budget & assembly strategy
- Estimate tokens for each item. If no token counter available, approximate: tokens ≈ words * 0.75.
- Always include: system instruction + user query.
- Prefer high-relevance items; if items exceed budget, truncate low-relevance items or switch to summaries.

## Provenance & Auditing
- When assembling a prompt, produce a "provenance block" listing:
  - item.id, source.uri, chunk_index, relevance_score, content_hash
- Retain the package_id and retrieval timestamp in logs.

## Safeguards
- Pre-retrieval filter: exclude items with sensitivity ∈ {restricted, sensitive} unless requester explicitly authorized.
- Post-retrieval policy check: run a PII/safety detector on candidate items and redact or drop offending content.
- Keep a guard-rail report: which items were redacted and why, for auditors.

## Use Case: Knowledge Base (KB)
- Typical items: docs, FAQs, how-tos, release notes.
- Chunking: paragraphs and section headings; 200–600 tokens per chunk.
- Metadata: product, version, locale, doc-type.
- Retrieval: prefer recent docs, filter by product/version.
- Prompt template: "Use the following docs to answer. If source incomplete, say you don't know."
- Special notes: keep changelogs & deprecations clearly tagged.

## Use Case: Code Assistant
- Items: source file chunks, function docstrings, code examples, tests.
- Chunking: function-based or class-based, keep full function bodies in same chunk when possible.
- Metadata: repo, file path, language, commit, license.
- Embedding strategy: use code-aware embeddings (if available).
- Retrieval: prefer items from same repo or same module, filter by language.
- Prompt assembly: include code fences and file path references; include provenance with commit SHA.
- Safety: filter secrets (API keys) by scanning before ingestion and mark as sensitive.

## Use Case: Helpdesk / Support Assistant
- Items: tickets, knowledge base articles, conversation history, system status pages.
- Chunking: ticket messages as turns, attach timestamps and agent ids.
- Metadata: customer id, SLA, product, ticket status.
- Retrieval: filter to customer's region/product and SLA level.
- Prompt assembly: include only final relevant turns and KB articles; avoid including other customers' PII.
- Safety: automatically redact PII and only show internal agent guidance if user is an agent.

## Example policies (operational)
- Retention: keep raw contents for 90 days; store only redacted content for 2 years.
- Authorization: only users with role=agent can retrieve items with sensitivity=internal.
- Verification: store content_hash and perform integrity checks daily.

## Observability
- Log: package_id, items_used, retrieval_scores, assembled_prompt_size, model_response_id.
- Expose: an audit endpoint to fetch packages and provenance for a given response id.

## Deployment notes
- Use a vector DB with metadata filtering (Pinecone, Weaviate, Milvus).
- For small-scale PoCs, use a local SQLite or Faiss + metadata table.
- Index embeddings with deterministic model and versioning.

## Conclusion
MCP is intentionally flexible: strict enough for auditability and provenance, permissive enough to support multiple storage and embedding strategies. For each use case, the primary differences are chunking strategy, metadata model, and policy filters.
```